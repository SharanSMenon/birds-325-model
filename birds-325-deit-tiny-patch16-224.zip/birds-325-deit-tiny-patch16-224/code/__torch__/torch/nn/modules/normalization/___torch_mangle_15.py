class LayerNorm(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.normalization.___torch_mangle_15.LayerNorm,
    input: Tensor) -> Tensor:
    _0 = self.bias
    _1 = self.weight
    input0 = torch.layer_norm(input, [192], _1, _0, 9.9999999999999995e-07)
    return input0
