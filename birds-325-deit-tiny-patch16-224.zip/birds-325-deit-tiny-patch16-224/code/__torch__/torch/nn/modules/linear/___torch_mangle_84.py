class Identity(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.linear.___torch_mangle_84.Identity) -> NoneType:
    return None
  def forward1(self: __torch__.torch.nn.modules.linear.___torch_mangle_84.Identity) -> NoneType:
    return None
