class VisionTransformer(Module):
  __parameters__ = ["cls_token", "pos_embed", ]
  __buffers__ = []
  cls_token : Tensor
  pos_embed : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  patch_embed : __torch__.timm.models.layers.patch_embed.PatchEmbed
  pos_drop : __torch__.torch.nn.modules.dropout.Dropout
  blocks : __torch__.torch.nn.modules.container.Sequential
  norm : __torch__.torch.nn.modules.normalization.___torch_mangle_162.LayerNorm
  pre_logits : __torch__.torch.nn.modules.linear.___torch_mangle_163.Identity
  head : __torch__.torch.nn.modules.container.___torch_mangle_167.Sequential
  def forward(self: __torch__.timm.models.vision_transformer.VisionTransformer,
    x: Tensor) -> Tensor:
    _0 = self.head
    _1 = self.pre_logits
    _2 = self.norm
    _3 = self.blocks
    _4 = self.pos_drop
    _5 = self.pos_embed
    _6 = self.cls_token
    _7 = (self.patch_embed).forward(x, )
    _8 = ops.prim.NumToTensor(torch.size(_7, 0))
    cls_token = torch.expand(_6, [int(_8), -1, -1])
    x0 = torch.cat([cls_token, _7], 1)
    input = torch.add(x0, _5)
    _9 = (_3).forward((_4).forward(input, ), )
    _10 = torch.slice((_2).forward(_9, ), 0, 0, 9223372036854775807)
    input0 = torch.select(_10, 1, 0)
    _11 = (_1).forward()
    return (_0).forward(input0, )
class Block(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.normalization.LayerNorm
  attn : __torch__.timm.models.vision_transformer.Attention
  drop_path : __torch__.torch.nn.modules.linear.___torch_mangle_3.Identity
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_4.LayerNorm
  mlp : __torch__.timm.models.layers.mlp.Mlp
  def forward(self: __torch__.timm.models.vision_transformer.Block,
    argument_1: Tensor) -> Tensor:
    _12 = self.mlp
    _13 = self.norm2
    _14 = self.drop_path
    _15 = (self.attn).forward((self.norm1).forward(argument_1, ), )
    _16 = (_14).forward()
    input = torch.add(argument_1, _15)
    _17 = (_12).forward((_13).forward(input, ), )
    _18 = (_14).forward1()
    return torch.add(input, _17)
class Attention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  qkv : __torch__.torch.nn.modules.linear.Linear
  attn_drop : __torch__.torch.nn.modules.dropout.___torch_mangle_0.Dropout
  proj : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  proj_drop : __torch__.torch.nn.modules.dropout.___torch_mangle_2.Dropout
  def forward(self: __torch__.timm.models.vision_transformer.Attention,
    argument_1: Tensor) -> Tensor:
    _19 = self.proj_drop
    _20 = self.proj
    _21 = self.attn_drop
    _22 = self.qkv
    B = ops.prim.NumToTensor(torch.size(argument_1, 0))
    _23 = int(B)
    _24 = int(B)
    N = ops.prim.NumToTensor(torch.size(argument_1, 1))
    _25 = int(N)
    _26 = int(N)
    C = ops.prim.NumToTensor(torch.size(argument_1, 2))
    _27 = int(C)
    _28 = (_22).forward(argument_1, )
    _29 = int(torch.floor_divide(C, CONSTANTS.c0))
    _30 = torch.reshape(_28, [_24, _26, 3, 3, _29])
    qkv = torch.permute(_30, [2, 0, 3, 1, 4])
    q = torch.select(qkv, 0, 0)
    k = torch.select(qkv, 0, 1)
    v = torch.select(qkv, 0, 2)
    _31 = torch.matmul(q, torch.transpose(k, -2, -1))
    attn = torch.mul(_31, CONSTANTS.c1)
    input = torch.softmax(attn, -1)
    _32 = torch.matmul((_21).forward(input, ), v)
    input1 = torch.reshape(torch.transpose(_32, 1, 2), [_23, _25, _27])
    _33 = (_19).forward((_20).forward(input1, ), )
    return _33
