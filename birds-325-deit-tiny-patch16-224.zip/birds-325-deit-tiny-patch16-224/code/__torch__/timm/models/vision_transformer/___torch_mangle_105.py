class Block(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  norm1 : __torch__.torch.nn.modules.normalization.___torch_mangle_92.LayerNorm
  attn : __torch__.timm.models.vision_transformer.___torch_mangle_97.Attention
  drop_path : __torch__.torch.nn.modules.linear.___torch_mangle_98.Identity
  norm2 : __torch__.torch.nn.modules.normalization.___torch_mangle_99.LayerNorm
  mlp : __torch__.timm.models.layers.mlp.___torch_mangle_104.Mlp
  def forward(self: __torch__.timm.models.vision_transformer.___torch_mangle_105.Block,
    argument_1: Tensor) -> Tensor:
    _0 = self.mlp
    _1 = self.norm2
    _2 = self.drop_path
    _3 = (self.attn).forward((self.norm1).forward(argument_1, ), )
    _4 = (_2).forward()
    input = torch.add(argument_1, _3)
    _5 = (_0).forward((_1).forward(input, ), )
    _6 = (_2).forward1()
    return torch.add(input, _5)
