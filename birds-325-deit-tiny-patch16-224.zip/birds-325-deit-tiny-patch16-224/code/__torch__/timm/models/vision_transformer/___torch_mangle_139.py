class Attention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  qkv : __torch__.torch.nn.modules.linear.___torch_mangle_135.Linear
  attn_drop : __torch__.torch.nn.modules.dropout.___torch_mangle_136.Dropout
  proj : __torch__.torch.nn.modules.linear.___torch_mangle_137.Linear
  proj_drop : __torch__.torch.nn.modules.dropout.___torch_mangle_138.Dropout
  def forward(self: __torch__.timm.models.vision_transformer.___torch_mangle_139.Attention,
    argument_1: Tensor) -> Tensor:
    _0 = self.proj_drop
    _1 = self.proj
    _2 = self.attn_drop
    _3 = self.qkv
    B = ops.prim.NumToTensor(torch.size(argument_1, 0))
    _4 = int(B)
    _5 = int(B)
    N = ops.prim.NumToTensor(torch.size(argument_1, 1))
    _6 = int(N)
    _7 = int(N)
    C = ops.prim.NumToTensor(torch.size(argument_1, 2))
    _8 = int(C)
    _9 = (_3).forward(argument_1, )
    _10 = int(torch.floor_divide(C, CONSTANTS.c0))
    _11 = torch.reshape(_9, [_5, _7, 3, 3, _10])
    qkv = torch.permute(_11, [2, 0, 3, 1, 4])
    q = torch.select(qkv, 0, 0)
    k = torch.select(qkv, 0, 1)
    v = torch.select(qkv, 0, 2)
    _12 = torch.matmul(q, torch.transpose(k, -2, -1))
    attn = torch.mul(_12, CONSTANTS.c1)
    input = torch.softmax(attn, -1)
    _13 = torch.matmul((_2).forward(input, ), v)
    input0 = torch.reshape(torch.transpose(_13, 1, 2), [_4, _6, _8])
    _14 = (_0).forward((_1).forward(input0, ), )
    return _14
