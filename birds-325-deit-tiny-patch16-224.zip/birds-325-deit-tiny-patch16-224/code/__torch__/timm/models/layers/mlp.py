class Mlp(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  fc1 : __torch__.torch.nn.modules.linear.___torch_mangle_5.Linear
  act : __torch__.torch.nn.modules.activation.GELU
  fc2 : __torch__.torch.nn.modules.linear.___torch_mangle_6.Linear
  drop : __torch__.torch.nn.modules.dropout.___torch_mangle_7.Dropout
  def forward(self: __torch__.timm.models.layers.mlp.Mlp,
    argument_1: Tensor) -> Tensor:
    _0 = self.fc2
    _1 = self.drop
    _2 = (self.act).forward((self.fc1).forward(argument_1, ), )
    _3 = (_1).forward1((_0).forward((_1).forward(_2, ), ), )
    return _3
