class PatchEmbed(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  proj : __torch__.torch.nn.modules.conv.Conv2d
  norm : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.timm.models.layers.patch_embed.PatchEmbed,
    x: Tensor) -> Tensor:
    _0 = self.norm
    _1 = torch.flatten((self.proj).forward(x, ), 2)
    x0 = torch.transpose(_1, 1, 2)
    _2 = (_0).forward()
    return x0
