class Mlp(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  fc1 : __torch__.torch.nn.modules.linear.___torch_mangle_44.Linear
  act : __torch__.torch.nn.modules.activation.___torch_mangle_45.GELU
  fc2 : __torch__.torch.nn.modules.linear.___torch_mangle_46.Linear
  drop : __torch__.torch.nn.modules.dropout.___torch_mangle_47.Dropout
  def forward(self: __torch__.timm.models.layers.mlp.___torch_mangle_48.Mlp,
    argument_1: Tensor) -> Tensor:
    _0 = self.fc2
    _1 = self.drop
    _2 = (self.act).forward((self.fc1).forward(argument_1, ), )
    _3 = (_1).forward1((_0).forward((_1).forward(_2, ), ), )
    return _3
